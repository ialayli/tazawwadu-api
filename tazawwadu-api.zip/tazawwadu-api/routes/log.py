from flask import Blueprint, request, jsonify
from database import db, ActivityLog

log_bp = Blueprint('log', __name__)

@log_bp.route('/', methods=['GET'])
def get_log():
    limit = int(request.args.get('limit', 50))
    log_type = request.args.get('type', None)
    q = ActivityLog.query
    if log_type:
        q = q.filter_by(type=log_type)
    entries = q.order_by(ActivityLog.created_at.desc()).limit(limit).all()
    return jsonify([{
        'id': e.id,
        'type': e.type,
        'title': e.title,
        'subtitle': e.subtitle,
        'created_at': e.created_at.isoformat()
    } for e in entries])
