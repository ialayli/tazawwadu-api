from flask import Blueprint, request, jsonify
from database import db, ActivityLog, Restaurant, NeedRequest, MealOffer
import re

whatsapp_bp = Blueprint('whatsapp', __name__)

# Simple keyword parser for WhatsApp messages
def parse_message(text: str):
    text_lower = text.strip().lower()
    # Food offer keywords
    if any(k in text_lower for k in ['وجبة', 'خبز', 'طعام', 'أكل', 'وجبات', 'متاح', 'عندنا']):
        # Try to extract quantity
        nums = re.findall(r'\d+', text)
        quantity = int(nums[0]) if nums else 0
        return {'type': 'food_offer', 'quantity': quantity, 'raw': text}
    # Need request keywords
    if any(k in text_lower for k in ['محتاج', 'نحتاج', 'نريد', 'طلب', 'مساعدة', 'جاعين']):
        nums = re.findall(r'\d+', text)
        people = int(nums[0]) if nums else 0
        return {'type': 'need_request', 'people': people, 'raw': text}
    return {'type': 'unknown', 'raw': text}

@whatsapp_bp.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    sender  = data.get('sender', '')
    message = data.get('message', '')
    name    = data.get('name', 'مجهول')

    parsed = parse_message(message)

    if parsed['type'] == 'food_offer':
        log = ActivityLog(
            type     = 'food',
            title    = f'🍽️ عرض طعام عبر واتساب — {name}',
            subtitle = f'{parsed["quantity"]} وجبة · {sender}'
        )
        db.session.add(log)
        db.session.commit()
        return jsonify({
            'reply': f'✅ شكراً {name}! تم تسجيل {parsed["quantity"]} وجبة. سيتم إبلاغ أقرب منطقة محتاجة تلقائياً. جزاك الله خيراً 🌿',
            'type': 'food_offer'
        })

    elif parsed['type'] == 'need_request':
        log = ActivityLog(
            type     = 'need',
            title    = f'🆘 طلب مساعدة عبر واتساب — {name}',
            subtitle = f'{parsed["people"]} شخص · {sender}'
        )
        db.session.add(log)
        db.session.commit()
        return jsonify({
            'reply': f'🤲 وصل طلبكم يا {name}. نبحث الآن عن أقرب مصدر طعام متاح وسنتواصل معكم خلال دقائق إن شاء الله 🌿',
            'type': 'need_request'
        })

    return jsonify({
        'reply': 'مرحباً بك في وَتَزَوَّدُوا 🌿\nأرسل "عندنا طعام" لتسجيل فائض، أو "نحتاج مساعدة" لطلب وجبات.',
        'type': 'unknown'
    })

@whatsapp_bp.route('/send', methods=['POST'])
def send_message():
    # This endpoint will be called by the Desktop App to send WhatsApp messages
    data = request.get_json()
    # In production, integrate with whatsapp-web.js running on Desktop
    return jsonify({'status': 'queued', 'to': data.get('to'), 'message': data.get('message')})
