from flask import Blueprint, request, jsonify
from database import db, Volunteer, ActivityLog

volunteers_bp = Blueprint('volunteers', __name__)

def vol_to_dict(v):
    return {
        'id': v.id,
        'name': v.name,
        'phone': v.phone,
        'whatsapp': v.whatsapp,
        'area': v.area,
        'vehicle': v.vehicle,
        'is_available': v.is_available,
        'created_at': v.created_at.isoformat()
    }

@volunteers_bp.route('/', methods=['GET'])
def get_volunteers():
    available_only = request.args.get('available', 'false').lower() == 'true'
    q = Volunteer.query
    if available_only:
        q = q.filter_by(is_available=True)
    vols = q.order_by(Volunteer.created_at.desc()).all()
    return jsonify([vol_to_dict(v) for v in vols])

@volunteers_bp.route('/', methods=['POST'])
def add_volunteer():
    data = request.get_json()
    v = Volunteer(
        name         = data.get('name', ''),
        phone        = data.get('phone', ''),
        whatsapp     = data.get('whatsapp', ''),
        area         = data.get('area', ''),
        vehicle      = data.get('vehicle', 'سيارة'),
        is_available = data.get('is_available', True)
    )
    db.session.add(v)
    db.session.flush()
    log = ActivityLog(
        type     = 'volunteer',
        title    = f'🚗 متطوع جديد — {v.name}',
        subtitle = f'{v.vehicle} · {v.area}'
    )
    db.session.add(log)
    db.session.commit()
    return jsonify(vol_to_dict(v)), 201

@volunteers_bp.route('/<int:vid>', methods=['PUT'])
def update_volunteer(vid):
    v = Volunteer.query.get_or_404(vid)
    data = request.get_json()
    for field in ['name', 'phone', 'whatsapp', 'area', 'vehicle', 'is_available']:
        if field in data:
            setattr(v, field, data[field])
    db.session.commit()
    return jsonify(vol_to_dict(v))

@volunteers_bp.route('/<int:vid>', methods=['DELETE'])
def delete_volunteer(vid):
    v = Volunteer.query.get_or_404(vid)
    db.session.delete(v)
    db.session.commit()
    return jsonify({'deleted': True})
