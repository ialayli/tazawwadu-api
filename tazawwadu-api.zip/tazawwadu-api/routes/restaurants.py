from flask import Blueprint, request, jsonify
from database import db, Restaurant, MealOffer, ActivityLog
from datetime import datetime

restaurants_bp = Blueprint('restaurants', __name__)

def restaurant_to_dict(r):
    return {
        'id': r.id,
        'name': r.name,
        'area': r.area,
        'phone': r.phone,
        'whatsapp': r.whatsapp,
        'description': r.description,
        'is_active': r.is_active,
        'created_at': r.created_at.isoformat(),
        'meals': [{
            'id': m.id,
            'meal_type': m.meal_type,
            'quantity': m.quantity,
            'available_at': m.available_at,
            'days': m.days,
            'is_available': m.is_available
        } for m in r.meals]
    }

@restaurants_bp.route('/', methods=['GET'])
def get_restaurants():
    active_only = request.args.get('active', 'false').lower() == 'true'
    q = Restaurant.query
    if active_only:
        q = q.filter_by(is_active=True)
    restaurants = q.order_by(Restaurant.created_at.desc()).all()
    return jsonify([restaurant_to_dict(r) for r in restaurants])

@restaurants_bp.route('/<int:rid>', methods=['GET'])
def get_restaurant(rid):
    r = Restaurant.query.get_or_404(rid)
    return jsonify(restaurant_to_dict(r))

@restaurants_bp.route('/', methods=['POST'])
def add_restaurant():
    data = request.get_json()
    r = Restaurant(
        name        = data.get('name', ''),
        area        = data.get('area', ''),
        phone       = data.get('phone', ''),
        whatsapp    = data.get('whatsapp', ''),
        description = data.get('description', '')
    )
    db.session.add(r)
    db.session.flush()
    # Add meal offers if provided
    for m in data.get('meals', []):
        offer = MealOffer(
            restaurant_id = r.id,
            meal_type     = m.get('meal_type', ''),
            quantity      = m.get('quantity', 0),
            available_at  = m.get('available_at', ''),
            days          = m.get('days', 'يومياً')
        )
        db.session.add(offer)
    # Log
    log = ActivityLog(type='food', title=f'🍽️ مطعم جديد — {r.name}', subtitle=r.area)
    db.session.add(log)
    db.session.commit()
    return jsonify(restaurant_to_dict(r)), 201

@restaurants_bp.route('/<int:rid>', methods=['PUT'])
def update_restaurant(rid):
    r = Restaurant.query.get_or_404(rid)
    data = request.get_json()
    for field in ['name', 'area', 'phone', 'whatsapp', 'description', 'is_active']:
        if field in data:
            setattr(r, field, data[field])
    db.session.commit()
    return jsonify(restaurant_to_dict(r))

@restaurants_bp.route('/<int:rid>', methods=['DELETE'])
def delete_restaurant(rid):
    r = Restaurant.query.get_or_404(rid)
    db.session.delete(r)
    db.session.commit()
    return jsonify({'deleted': True})

@restaurants_bp.route('/<int:rid>/meals', methods=['POST'])
def add_meal(rid):
    Restaurant.query.get_or_404(rid)
    data = request.get_json()
    m = MealOffer(
        restaurant_id = rid,
        meal_type     = data.get('meal_type', ''),
        quantity      = data.get('quantity', 0),
        available_at  = data.get('available_at', ''),
        days          = data.get('days', 'يومياً')
    )
    db.session.add(m)
    db.session.commit()
    return jsonify({'id': m.id}), 201
