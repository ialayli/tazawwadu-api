from flask import Blueprint, jsonify
from database import db, Restaurant, NeedRequest, Volunteer, Match, MealOffer

stats_bp = Blueprint('stats', __name__)

@stats_bp.route('/', methods=['GET'])
def get_stats():
    total_restaurants  = Restaurant.query.filter_by(is_active=True).count()
    total_needs        = NeedRequest.query.filter_by(is_active=True).count()
    total_volunteers   = Volunteer.query.filter_by(is_available=True).count()
    total_matches      = Match.query.count()
    delivered_matches  = Match.query.filter_by(status='delivered').count()
    total_meals_today  = db.session.query(
        db.func.sum(MealOffer.quantity)
    ).filter_by(is_available=True).scalar() or 0
    total_people_helped = db.session.query(
        db.func.sum(NeedRequest.people)
    ).filter_by(is_active=True).scalar() or 0

    return jsonify({
        'restaurants': total_restaurants,
        'needs': total_needs,
        'volunteers': total_volunteers,
        'matches_total': total_matches,
        'matches_delivered': delivered_matches,
        'meals_available': int(total_meals_today),
        'people_helped': int(total_people_helped)
    })
