from flask import Blueprint, request, jsonify
from database import db, NeedRequest, ActivityLog

needs_bp = Blueprint('needs', __name__)

def need_to_dict(n):
    return {
        'id': n.id,
        'name': n.name,
        'area': n.area,
        'phone': n.phone,
        'whatsapp': n.whatsapp,
        'people': n.people,
        'meal_type': n.meal_type,
        'frequency': n.frequency,
        'urgency': n.urgency,
        'is_active': n.is_active,
        'created_at': n.created_at.isoformat()
    }

@needs_bp.route('/', methods=['GET'])
def get_needs():
    active_only = request.args.get('active', 'false').lower() == 'true'
    q = NeedRequest.query
    if active_only:
        q = q.filter_by(is_active=True)
    needs = q.order_by(NeedRequest.urgency.desc(), NeedRequest.created_at.desc()).all()
    return jsonify([need_to_dict(n) for n in needs])

@needs_bp.route('/<int:nid>', methods=['GET'])
def get_need(nid):
    n = NeedRequest.query.get_or_404(nid)
    return jsonify(need_to_dict(n))

@needs_bp.route('/', methods=['POST'])
def add_need():
    data = request.get_json()
    n = NeedRequest(
        name      = data.get('name', ''),
        area      = data.get('area', ''),
        phone     = data.get('phone', ''),
        whatsapp  = data.get('whatsapp', ''),
        people    = data.get('people', 0),
        meal_type = data.get('meal_type', ''),
        frequency = data.get('frequency', 'يومياً'),
        urgency   = data.get('urgency', 'medium')
    )
    db.session.add(n)
    db.session.flush()
    log = ActivityLog(
        type     = 'need',
        title    = f'🆘 طلب جديد — {n.name}',
        subtitle = f'{n.people} شخص · {n.area}'
    )
    db.session.add(log)
    db.session.commit()
    return jsonify(need_to_dict(n)), 201

@needs_bp.route('/<int:nid>', methods=['PUT'])
def update_need(nid):
    n = NeedRequest.query.get_or_404(nid)
    data = request.get_json()
    for field in ['name', 'area', 'phone', 'whatsapp', 'people', 'meal_type', 'frequency', 'urgency', 'is_active']:
        if field in data:
            setattr(n, field, data[field])
    db.session.commit()
    return jsonify(need_to_dict(n))

@needs_bp.route('/<int:nid>', methods=['DELETE'])
def delete_need(nid):
    n = NeedRequest.query.get_or_404(nid)
    db.session.delete(n)
    db.session.commit()
    return jsonify({'deleted': True})
