# وَتَزَوَّدُوا — Flask API

## التشغيل المحلي
```bash
pip install -r requirements.txt
python app.py
# يشتغل على http://localhost:5050
```

## النشر على Render.com (مجاناً)
1. ارفع المجلد على GitHub
2. افتح render.com → New Web Service
3. اربطه بالـ repo
4. Render يقرأ render.yaml تلقائياً ✅

---

## API Endpoints

### ✅ الحالة
```
GET /
→ { status: "ok", app: "وَتَزَوَّدُوا API", version: "1.0.0" }
```

### 📊 الإحصائيات
```
GET /api/stats/
→ {
    restaurants, needs, volunteers,
    matches_total, matches_delivered,
    meals_available, people_helped
  }
```

### 🍽️ المطاعم
```
GET    /api/restaurants/           → كل المطاعم
GET    /api/restaurants/?active=true → النشطة فقط
GET    /api/restaurants/<id>       → مطعم محدد
POST   /api/restaurants/           → إضافة مطعم
PUT    /api/restaurants/<id>       → تعديل
DELETE /api/restaurants/<id>       → حذف
POST   /api/restaurants/<id>/meals → إضافة وجبة للمطعم
```

**POST body مثال:**
```json
{
  "name": "مطعم الريف",
  "area": "الحمرا، بيروت",
  "phone": "01123456",
  "whatsapp": "+96171234567",
  "description": "مطعم لبناني",
  "meals": [
    {
      "meal_type": "وجبات دافئة",
      "quantity": 25,
      "available_at": "2م - 4م",
      "days": "يومياً"
    }
  ]
}
```

### 🆘 المحتاجون
```
GET    /api/needs/              → كل الطلبات
GET    /api/needs/?active=true  → النشطة فقط
GET    /api/needs/<id>
POST   /api/needs/
PUT    /api/needs/<id>
DELETE /api/needs/<id>
```

**POST body مثال:**
```json
{
  "name": "عائلات النويري",
  "area": "النويري، بيروت الغربية",
  "phone": "01987654",
  "whatsapp": "+96170123456",
  "people": 12,
  "meal_type": "وجبة مساء",
  "frequency": "يومياً",
  "urgency": "high"
}
```

### 🚗 المتطوعون
```
GET    /api/volunteers/
GET    /api/volunteers/?available=true
POST   /api/volunteers/
PUT    /api/volunteers/<id>
DELETE /api/volunteers/<id>
```

### 📋 السجل
```
GET /api/log/              → كل السجل (آخر 50)
GET /api/log/?limit=20     → تحديد العدد
GET /api/log/?type=food    → food / need / match / volunteer
```

### 📱 واتساب
```
POST /api/whatsapp/webhook  → استقبال رسائل من whatsapp-web.js
POST /api/whatsapp/send     → إرسال رسالة (من Desktop App)
```

**Webhook body:**
```json
{
  "sender": "+96171234567",
  "name": "أحمد",
  "message": "عندنا 20 وجبة اليوم"
}
```

---

## urgency values
- `high` → عاجل (أحمر)
- `medium` → متوسط (ذهبي)
- `low` → عادي (أخضر)

## match status values
- `pending` → في الانتظار
- `in_progress` → جاري التوصيل
- `delivered` → تم التوصيل ✅
