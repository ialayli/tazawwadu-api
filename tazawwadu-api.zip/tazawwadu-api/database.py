from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Restaurant(db.Model):
    __tablename__ = 'restaurants'
    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(120), nullable=False)
    area        = db.Column(db.String(100))
    phone       = db.Column(db.String(30))
    whatsapp    = db.Column(db.String(30))
    description = db.Column(db.Text)
    is_active   = db.Column(db.Boolean, default=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    meals       = db.relationship('MealOffer', backref='restaurant', lazy=True, cascade='all, delete-orphan')

class MealOffer(db.Model):
    __tablename__ = 'meal_offers'
    id            = db.Column(db.Integer, primary_key=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurants.id'), nullable=False)
    meal_type     = db.Column(db.String(80))   # وجبات دافئة / خبز / بضائع
    quantity      = db.Column(db.Integer, default=0)
    available_at  = db.Column(db.String(50))   # "2م - 4م"
    days          = db.Column(db.String(100))  # "يومياً" / "الجمعة والسبت"
    is_available  = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)

class NeedRequest(db.Model):
    __tablename__ = 'need_requests'
    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(120), nullable=False)
    area        = db.Column(db.String(100))
    phone       = db.Column(db.String(30))
    whatsapp    = db.Column(db.String(30))
    people      = db.Column(db.Integer, default=0)
    meal_type   = db.Column(db.String(80))   # غداء / عشاء / فطور
    frequency   = db.Column(db.String(80))   # يومياً / أسبوعياً
    urgency     = db.Column(db.String(20), default='medium')  # high / medium / low
    is_active   = db.Column(db.Boolean, default=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class Volunteer(db.Model):
    __tablename__ = 'volunteers'
    id          = db.Column(db.Integer, primary_key=True)
    name        = db.Column(db.String(120), nullable=False)
    phone       = db.Column(db.String(30))
    whatsapp    = db.Column(db.String(30))
    area        = db.Column(db.String(100))
    vehicle     = db.Column(db.String(50))   # سيارة / دراجة / مشياً
    is_available= db.Column(db.Boolean, default=True)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class Match(db.Model):
    __tablename__ = 'matches'
    id            = db.Column(db.Integer, primary_key=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurants.id'))
    need_id       = db.Column(db.Integer, db.ForeignKey('need_requests.id'))
    volunteer_id  = db.Column(db.Integer, db.ForeignKey('volunteers.id'), nullable=True)
    quantity      = db.Column(db.Integer, default=0)
    status        = db.Column(db.String(30), default='pending')  # pending / in_progress / delivered
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    delivered_at  = db.Column(db.DateTime, nullable=True)

class ActivityLog(db.Model):
    __tablename__ = 'activity_log'
    id         = db.Column(db.Integer, primary_key=True)
    type       = db.Column(db.String(30))   # food / need / match / volunteer
    title      = db.Column(db.String(200))
    subtitle   = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
