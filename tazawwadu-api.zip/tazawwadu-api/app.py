from flask import Flask
from flask_cors import CORS
from database import db
from routes.restaurants import restaurants_bp
from routes.needs import needs_bp
from routes.volunteers import volunteers_bp
from routes.log import log_bp
from routes.stats import stats_bp
from routes.whatsapp import whatsapp_bp
import os

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///tazawwadu.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'tazawwadu_secret_2025')

db.init_app(app)

app.register_blueprint(restaurants_bp, url_prefix='/api/restaurants')
app.register_blueprint(needs_bp,       url_prefix='/api/needs')
app.register_blueprint(volunteers_bp,  url_prefix='/api/volunteers')
app.register_blueprint(log_bp,         url_prefix='/api/log')
app.register_blueprint(stats_bp,       url_prefix='/api/stats')
app.register_blueprint(whatsapp_bp,    url_prefix='/api/whatsapp')

@app.route('/')
def index():
    return {'status': 'ok', 'app': 'وَتَزَوَّدُوا API', 'version': '1.0.0'}

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5050))
    app.run(host='0.0.0.0', port=port, debug=False)
